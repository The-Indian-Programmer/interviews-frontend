// ** Core JWT Import
import useJwt from '../../@core/auth/jwt/useJwt'

const { jwt } = useJwt({})

export default jwt
