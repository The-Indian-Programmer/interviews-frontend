import React from 'react'

const CreatePostMessage = () => {
  return (
    <div className=" bg-gray-800 text-white p-4  mx-1">
    <span  className="font-extrabold">

    You post will be visible to everyone, Please wait......
    </span>
  </div>
  )
}

export default CreatePostMessage