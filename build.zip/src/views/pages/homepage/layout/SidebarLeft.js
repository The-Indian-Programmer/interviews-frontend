import React from 'react'

const SidebarLeft = () => {
  return (
    <aside className="col-span-0 hidden sm:hidden md:hidden lg:block xl:block 2xl:block sm:col-span-0 md:col-span-0 lg:col-span-3 xl:col-span-3 2xl:col-span-3  bg-black p-4 sticky top-20">
      
    </aside>
  )
}

export default SidebarLeft