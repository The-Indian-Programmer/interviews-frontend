import React from 'react'

const Allfunders = () => {
  return (
    <div>
      funders
    </div>
  )
}

export default Allfunders
